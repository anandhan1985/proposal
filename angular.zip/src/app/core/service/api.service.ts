import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { map } from 'rxjs/operators'

@Injectable()
export class ApiService {
  constructor(private http: HttpClient) { }

  public getProposal(): Observable<any> {
    return this.http.get('http://localhost:3000/hvc/aggregatorSearch').pipe(map(res => res));
  }
  
}