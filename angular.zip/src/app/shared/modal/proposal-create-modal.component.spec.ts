import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateProposalModalComponent } from './proposal-create-modal.component';

describe('CreateProposalModalComponent', () => {
  let component: CreateProposalModalComponent;
  let fixture: ComponentFixture<CreateProposalModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CreateProposalModalComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateProposalModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
