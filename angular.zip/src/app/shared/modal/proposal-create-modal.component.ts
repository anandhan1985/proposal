import { Component, OnInit, Input, Output, OnChanges, EventEmitter } from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { CreateProposalService } from '../../modules/proposal/shared/proposal-create.service';
import { Router } from '@angular/router'; 
@Component({
  selector: 'app-dialog',
  templateUrl: './proposal-create-modal.component.html',

  styleUrls: ['./proposal-create-modal.component.scss'],
  animations: [
    trigger('dialog', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class CreateProposalModalComponent implements OnInit {
  @Input() closable = true;
  @Input() visible: boolean;
  @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();
public proposalFormData:any;
  constructor(public router:Router,private CreateProposalService: CreateProposalService) { }

  ngOnInit() { 
  this.CreateProposalService.proposalDataCreate();
	 this.proposalFormData=this.CreateProposalService.proposalDataCreate();
	 //console.log(this.proposalFormData);
  }
createProposal(){
		this.router.navigate(['/proposalcreate']);
}
  
  close() {
    this.visible = false;
    this.visibleChange.emit(this.visible);
  }
}