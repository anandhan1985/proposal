import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

const DATA= [{ "checked": "false", "promotioncode": "DF20150926", "description": "DF CRUISE SALTING DATE", "category" : 'MISC'},
      { "checked": "false", "promotioncode": "DF20150927", "description": "DF CRUISE SALTING DATE", "category" : 'MISC' },
      { "checked": "false", "promotioncode": "DF20150928", "description": "DF CRUISE SALTING DATE", "category" : 'MISC' }]

@Component({
  selector: 'app-proposal-promotion-dialog',
  templateUrl: './proposal-promotion-dialog.component.html',
  styleUrls: ['./proposal-promotion-dialog.component.scss']
})
export class ProposalPromotionDialogComponent implements OnInit {
  private selectedPromotions: any = [];
  private displayedColumns: string[] = ['checked', 'promotioncode', 'description', 'category'];
  private dataSource = DATA;
  constructor(public dialogRef: MatDialogRef<ProposalPromotionDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  ngOnInit() {
  }

  promotionClick(promotionCode) {
    let promotionData = this.selectedPromotions.indexOf(promotionCode);
    if (promotionData != -1)
      this.selectedPromotions.splice(promotionData, 1);
    else
      this.selectedPromotions.push(promotionCode);
    console.log(this.selectedPromotions);
  }

  onOkClick() {
    this.dialogRef.close(this.selectedPromotions);
  }

  onNoClick() {
    this.dialogRef.close(this.selectedPromotions);
  }

}
