import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposalPromotionDialogComponent } from './proposal-promotion-dialog.component';

describe('ProposalPromotionDialogComponent', () => {
  let component: ProposalPromotionDialogComponent;
  let fixture: ComponentFixture<ProposalPromotionDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProposalPromotionDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposalPromotionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
