import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { shareReplay, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CreateProposalService {
  private cache: Observable<any>;
  public proposalData: any;

  constructor(private http: HttpClient) { }
  public locationValue = new Subject<any>();
  public addInfoValue = new Subject<any>();
  public titleInsuranceValue = new Subject<any>();
  public salesLocationValue = new Subject<any>();
  public getLocationReceived = this.locationValue.asObservable();
  public getSalesLocationReceived = this.salesLocationValue.asObservable();
  public getAddInfoReceived = this.addInfoValue.asObservable();
  public getTitleReceived = this.titleInsuranceValue.asObservable();
  public resortData: any;
  public resortDetail: any;
  public createProposal: any;

  public createPropValue = {
    "msmNo": "",
    "points": "",
    "masterUseMonth": "",
    "proposalType": "",
    "contractType": "",
    "resort": "",
    "salesLocation": "",
    "locDate": "",
    "mailOutFlag": "",
    "edocsOutFlag": "",
    "trustFlag": "",
    "secondMasterFlag": "",
    "rewriteFlag": "",
    "corporationLLCFlag": "",
    "corportationLLCName": "",
    "stateID": 0,
    "titleCode": 0,
    "guideID": 0,
    "coGuideID": 0,
    "qamID": 0,
    "specialInstructions": "",
    "promotion": []
  }

  getCreateProposalData(): Observable<any> {
    return this.http.get('http://localhost:3000/hvc/aggregatorProposal').pipe(map(response => {
      this.proposalData = response;
      return this.proposalData;
    }));
  }

  createProposalFormData(data) {
    this.createProposal = data;
    return this.createProposal;
  }

  proposalDataCreate() {
    if (this.createProposal == undefined) {
      let resortdata = localStorage.getItem("resortdata");
      this.createProposal = JSON.parse(resortdata);
    }
    return this.createProposal;
  }

  resortDetails(resortName, resortPoints) {
    this.resortData = { 'resortname': resortName, 'resortpoints': resortPoints };
  }

  resortDataPointsName() {
    if (this.resortData == undefined) {
      let resortdata = localStorage.getItem("resortdata");
      this.resortData = JSON.parse(resortdata);
    }
    return this.resortData;
  }

  getProposalData() {
    if (!this.cache) {
      this.cache = this.getCreateProposalData().pipe(
        shareReplay(10)
      );
    }
    return this.cache;
  }

  getAvailablePromotionsData(): Observable<any> {
    let memberType = this.proposalData["memberInfo"][0]["memeberType"];
    let params = { "location": this.createPropValue.salesLocation, "membertype": memberType, "resort": this.createPropValue.resort };
    return this.http.get('http://localhost:3000/hvc/promotions', { params: params }).pipe(map(response => {
      return response
    }));
  }

  setLocationVal() {
    this.locationValue.next();
  }

  setAddInfoVal() {
    this.addInfoValue.next();
  }

  setTitleInsuranceVal() {
    this.titleInsuranceValue.next();
  }

  setSalesLocationVal(data) {
    this.salesLocationValue.next(data);
  }

  postProposalData(): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "X-Requested-With"
      })
    };
    this.createPropValue.msmNo = this.createProposal.msm;
    this.createPropValue.points = this.createProposal.points;
    this.createPropValue.proposalType = this.createProposal.proposalType;
    this.createPropValue.masterUseMonth = this.createProposal.masterUseMonth;
    this.createPropValue.contractType = this.createProposal.contractType;
    delete this.createPropValue.locDate;
    return this.http.post<any>('http://localhost:3000/hvc/submitProposal', this.createPropValue, httpOptions).pipe(map(response => {
      return response;
    }));
  }

}
