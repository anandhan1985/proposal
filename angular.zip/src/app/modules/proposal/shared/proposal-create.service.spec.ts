import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { CreateProposalService } from './proposal-create.service';

describe('CreateProposalService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
  }));

  it('should be created', () => {
    const service: CreateProposalService = TestBed.get(CreateProposalService);
    expect(service).toBeTruthy();
  });
});
