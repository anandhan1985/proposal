import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProposalSearchComponent } from './proposal-search/proposal-search.component';
import { ProposalCreateComponent } from './proposal-create/proposal-create.component';
import { ProposalMemberComponent } from './proposal-create/proposal-member/proposal-member.component';
import { ProposalSalesChannelComponent } from './proposal-create/proposal-sales-channel/proposal-sales-channel.component';
import { ProposalTitleInsuranceComponent } from './proposal-create/proposal-title-insurance/proposal-title-insurance.component';
import { ProposalPromotionCodesComponent } from './proposal-create/proposal-promotion-codes/proposal-promotion-codes.component';
import { ProposalAdditionalInfoComponent } from './proposal-create/proposal-additional-info/proposal-additional-info.component';


const routes: Routes = [
  { path: 'proposalsearch', component: ProposalSearchComponent },
  {
    path: 'proposalcreate', component: ProposalCreateComponent,
    children: [
      { path: '', redirectTo: 'saleschannel', pathMatch: 'full' },
      { path: 'saleschannel', component: ProposalSalesChannelComponent },
      { path: 'membersummary', component: ProposalMemberComponent },
      { path: 'titleinsurance', component: ProposalTitleInsuranceComponent },
      { path: 'promotioncodes', component: ProposalPromotionCodesComponent },
      { path: 'additionalinfo', component: ProposalAdditionalInfoComponent },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProposalRoutingModule { }
