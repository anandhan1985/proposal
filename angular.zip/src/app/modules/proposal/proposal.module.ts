import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatTabsModule } from '@angular/material/tabs';

import { ProposalRoutingModule } from './proposal-routing.module';
import { HttpClientModule } from '@angular/common/http';

import { ProposalSearchComponent } from './proposal-search/proposal-search.component';
import { ProposalCreateComponent } from './proposal-create/proposal-create.component';
import { ProposalMemberComponent } from './proposal-create/proposal-member/proposal-member.component';
import { ProposalSalesChannelComponent } from './proposal-create/proposal-sales-channel/proposal-sales-channel.component';
import { ProposalTitleInsuranceComponent } from './proposal-create/proposal-title-insurance/proposal-title-insurance.component';
import { ProposalPromotionCodesComponent } from './proposal-create/proposal-promotion-codes/proposal-promotion-codes.component';
import { ProposalAdditionalInfoComponent } from './proposal-create/proposal-additional-info/proposal-additional-info.component';
import { CreateProposalModalComponent } from '../../shared/modal/proposal-create-modal.component';
import { CreateProposalService } from '../../modules/proposal/shared/proposal-create.service';

@NgModule({
  declarations: [
    ProposalSearchComponent,
    ProposalCreateComponent,
    ProposalMemberComponent,
    ProposalSalesChannelComponent,
    ProposalTitleInsuranceComponent,
    ProposalPromotionCodesComponent,
    ProposalAdditionalInfoComponent,
    CreateProposalModalComponent,
  ],
  imports: [
    CommonModule,
    ProposalRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    MatTabsModule
  ],
  exports: [
    ProposalSearchComponent,
    ProposalCreateComponent,
    ProposalMemberComponent,
    ProposalSalesChannelComponent,
    ProposalTitleInsuranceComponent,
    ProposalPromotionCodesComponent,
    ProposalAdditionalInfoComponent
  ],
  providers: [CreateProposalService],

})
export class ProposalModule { }
