import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { By } from "@angular/platform-browser";
import { RouterTestingModule } from '@angular/router/testing';

import { ProposalSearchComponent } from './proposal-search.component';
import { CreateProposalModalComponent } from './../../../shared/modal/proposal-create-modal.component';

import { ApiService } from '../../../core/service/api.service';

describe('ProposalComponent,ApiService', () => {
  let component: ProposalSearchComponent;
  let fixture: ComponentFixture<ProposalSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProposalSearchComponent,
        CreateProposalModalComponent],
      imports: [
        BrowserModule,
        ReactiveFormsModule,
        FormsModule,
        HttpClientTestingModule,
        RouterTestingModule
      ],
      providers: [ApiService]
    })
      .compileComponents().then(() => {
        fixture = TestBed.createComponent(ProposalSearchComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
      });
  }));

  it('form should be invalid', async(() => {
    component.newProposal.controls["msm"].setValue('');
    component.newProposal.controls["points"].setValue('');
    component.newProposal.controls["proposalType"].setValue('');
    component.newProposal.controls["masterUseMonth"].setValue('');
    component.newProposal.controls["resort"].setValue('');
    component.newProposal.controls["contractType"].setValue('');
    expect(component.newProposal.valid).toBeFalsy();
  }));
  it('form should be valid', async(() => {
    component.newProposal.controls["msm"].setValue('1234');
    component.newProposal.controls["points"].setValue('12');
    component.newProposal.controls["proposalType"].setValue('New Master Contract');
    component.newProposal.controls["masterUseMonth"].setValue('Jan');
    component.newProposal.controls["resort"].setValue('POLYV - HCL Polynesian Villas and Bungalow');
    component.newProposal.controls["contractType"].setValue('Standard Points Contract');
    expect(component.newProposal.valid).toBeTruthy();
  }));

  it('should be ok', async(() => {
    // Update the msm input
    const inputElement = fixture.debugElement.query(By.css('input[name="msm"]')).nativeElement;
    inputElement.value = 'Updated msm';
    inputElement.dispatchEvent(new Event('input'));
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(inputElement.value).toEqual('Updated msm');
    });
  }));

  it('should be ok', async(() => {
    // Update the points input
    const inputElement = fixture.debugElement.query(By.css('input[name="points"]')).nativeElement;
    inputElement.value = 'Updated points';
    inputElement.dispatchEvent(new Event('input'));
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(inputElement.value).toEqual('Updated points');
    });
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
