import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { from, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ApiService } from '../../../core/service/api.service';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { CreateProposalService } from './../shared/proposal-create.service';

@Component({
  selector: 'app-proposal',
  templateUrl: './proposal-search.component.html',
  styleUrls: ['./proposal-search.component.scss'],
  animations: [
    trigger('dialog', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class ProposalSearchComponent implements OnInit {
  newProposal: FormGroup;
  proposalType: any[];
  masterUseMonth: any[];
  resort: any[];
  resortPoint: number = 0;
  pointsVal: number = 0;
  pointPrice: number = 0;
  resortNameOption: any;
  sumOfPoints: any;
  private selectedResort: any;
  proposal = new Array();
  constructor(private fb: FormBuilder, private apiservice: ApiService, private createProposalservice: CreateProposalService) {

  }
  submitted = false;

  ngOnInit() {
    this.newProposal = this.fb.group({
      msm: ['', Validators.required],
      points: ['', Validators.required],
      proposalType: ['', Validators.required],
      masterUseMonth: ['', Validators.required],
      resort: ['', Validators.required],
      contractType: ['', Validators.required]
    })

    this.apiservice.getProposal().subscribe(response => {
      let data = response
      this.resort = data.resorts
    })
    this.proposalType = [{ id: 1, type: "New Master Contract" }, { id: 2, type: "New add on for existing contract" }, { id: 3, type: "new add on for new proposal " }]
    this.masterUseMonth = [
      { "id": 1, "month": "Jan" }, { "id": 2, "month": "Feb" }, { "id": 3, "month": "Mar" }, { "id": 4, "month": "Apr" }, { "id": 5, "month": "May" }, { "id": 6, "month": "June" }, { "id": 7, "month": "July" }, { "id": 8, "month": "Aug" }, { "id": 9, "month": "Sep" }, { "id": 10, "month": "Oct" }, { "id": 11, "month": "Nov" }, { "id": 12, "month": "Dec" }]
  }

  get f() { return this.newProposal.controls; }

  onSubmit() {
    this.createProposalservice.createProposalFormData(this.newProposal.value)
    let proposalData = this.newProposal.value;
    proposalData["resortpoints"] = this.sumOfPoints;
    proposalData["resortname"] = this.resortNameOption;
    localStorage.setItem("resortdata", JSON.stringify(proposalData));

  }
  changedVal(e) {
    this.selectedResort = this.resort.filter(function (item) { return item.resort === e.target.value });
    this.resortPoint = this.selectedResort[0].resortPointPrice;
    this.sumOfPoints = this.resortPoint * this.pointsVal;
    this.resortNameOption = e.target.options[e.target.selectedIndex].text;
    this.createProposalservice.resortDetails(this.resortNameOption, this.sumOfPoints);

  }
  pointVal(val) {
    this.pointsVal = val;
  }
  cancel() {
    this.newProposal.reset();
  }



}
