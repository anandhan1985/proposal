import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { ProposalTitleInsuranceComponent } from './proposal-title-insurance.component';

describe('ProposalTitleInsuranceComponent', () => {
  let component: ProposalTitleInsuranceComponent;
  let fixture: ComponentFixture<ProposalTitleInsuranceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProposalTitleInsuranceComponent],
      imports: [FormsModule, ReactiveFormsModule, HttpClientTestingModule],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposalTitleInsuranceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
