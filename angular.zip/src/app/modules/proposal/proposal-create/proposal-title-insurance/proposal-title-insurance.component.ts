import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { CreateProposalService } from './../../shared/proposal-create.service';

@Component({
  selector: 'app-proposal-title-insurance',
  templateUrl: './proposal-title-insurance.component.html',
  styleUrls: ['./proposal-title-insurance.component.scss']
})
export class ProposalTitleInsuranceComponent implements OnInit {
  public titleProposalData: any = [];
  titleFG: FormGroup;
  constructor(private CreateProposalService: CreateProposalService, private fb: FormBuilder) {
    this.titleFG = this.fb.group({
      tiltleCode: []
    })
  }
  ngOnInit() {
    this.getProposalTitleInsuranceData();
    this.setProposalTitleInsuranceData();
    this.CreateProposalService.getTitleReceived.subscribe(data => {
      this.getTitleVal();
    });
  }
  getProposalTitleInsuranceData() {
    this.CreateProposalService.getProposalData().subscribe((data) => {
      if (data["titles"])
        this.titleProposalData = data["titles"];
    });
  }

  setProposalTitleInsuranceData() {
    this.titleFG.setValue({
      tiltleCode: this.CreateProposalService.createPropValue.titleCode
    });
  }

  getTitleVal() {
    let titleVal: any = this.titleFG.value;
    this.CreateProposalService.createPropValue.titleCode = titleVal.tiltleCode;
  }

  ngOnDestroy() {
    this.getTitleVal();
  }
}
