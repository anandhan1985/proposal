import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { ProposalSalesChannelComponent } from './proposal-sales-channel.component';

describe('ProposalSalesChannelComponent', () => {
  let component: ProposalSalesChannelComponent;
  let fixture: ComponentFixture<ProposalSalesChannelComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProposalSalesChannelComponent],
      imports: [FormsModule, ReactiveFormsModule, HttpClientTestingModule],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposalSalesChannelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
