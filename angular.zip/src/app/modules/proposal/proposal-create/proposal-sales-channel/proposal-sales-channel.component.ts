import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { CreateProposalService } from './../../shared/proposal-create.service';

@Component({
  selector: 'app-proposal-sales-channel',
  templateUrl: './proposal-sales-channel.component.html',
  styleUrls: ['./proposal-sales-channel.component.scss']
})
export class ProposalSalesChannelComponent implements OnInit {
  private salesChannelData: any = [];
  private locationData: any = [];
  private stateOfCorporationData: any = [];
  locationFG: FormGroup;
  locationDS: any[];
  constructor(private fb: FormBuilder, private CreateProposalService: CreateProposalService) {
    this.locationFG = this.fb.group({
      celebration: [],
      date: [""],
      mailOut: [null],
      eDocsOut: [null],
      trust: [""],
      secondMaster: [""],
      rewrite: [""],
      CorpLLC: [""],
      CorpLLCName: [""],
      StateLLC: [null]
    })
  }

  ngOnInit() {
    this.getSalesChannelData();
    this.setSalesChannelData();

    this.CreateProposalService.getLocationReceived.subscribe(data => {
      this.getLocationVal();
    });
    this.locationFG.controls["celebration"].valueChanges.subscribe(data => {
      this.CreateProposalService.setSalesLocationVal(data);
    });
  }

  setSalesChannelData() {
    this.locationFG.patchValue({
      celebration: this.CreateProposalService.createPropValue.salesLocation,
      date: this.CreateProposalService.createPropValue.locDate,
      mailOut: this.CreateProposalService.createPropValue.mailOutFlag,
      eDocsOut: this.CreateProposalService.createPropValue.edocsOutFlag,
      trust: (this.CreateProposalService.createPropValue.trustFlag == "Y") ? true : false,
      secondMaster: (this.CreateProposalService.createPropValue["secondMasterFlag"] == "Y") ? true : false,
      rewrite: (this.CreateProposalService.createPropValue.rewriteFlag == "Y") ? true : false,
      CorpLLC: (this.CreateProposalService.createPropValue.corporationLLCFlag == "Y") ? true : false,
      CorpLLCName: this.CreateProposalService.createPropValue.corportationLLCName,
      StateLLC: this.CreateProposalService.createPropValue.stateID
    });
  }

  cancel() {
    //<button class="secondaryButton marginLeft10px marginRight10px" (click)="cancel()">test</button>
    console.log(JSON.stringify(this.locationFG.value))
  }

  getLocationVal() {
    let locVal: any = this.locationFG.value;
    this.CreateProposalService.createPropValue.salesLocation = locVal.celebration;
    this.CreateProposalService.createPropValue.locDate = locVal.date;
    this.CreateProposalService.createPropValue.mailOutFlag = locVal.mailOut;
    this.CreateProposalService.createPropValue.edocsOutFlag = locVal.eDocsOut;
    this.CreateProposalService.createPropValue.trustFlag = "N";
    if (locVal.trust) {
      this.CreateProposalService.createPropValue.trustFlag = "Y";
    }
    this.CreateProposalService.createPropValue["secondMasterFlag"] = "N";
    if (locVal.secondMaster) {
      this.CreateProposalService.createPropValue["secondMasterFlag"] = "Y";
    }
    this.CreateProposalService.createPropValue.rewriteFlag = "N";
    if (locVal.rewrite) {
      this.CreateProposalService.createPropValue.rewriteFlag = "Y";
    }
    this.CreateProposalService.createPropValue.corporationLLCFlag = "N";
    if (locVal.CorpLLC) {
      this.CreateProposalService.createPropValue.corporationLLCFlag = "Y";
    }
    this.CreateProposalService.createPropValue.corportationLLCName = locVal.CorpLLCName;
    this.CreateProposalService.createPropValue.stateID = locVal.StateLLC;
  }

  getSalesChannelData() {
    this.CreateProposalService.getProposalData().subscribe((data) => {
      if (data) {
        this.salesChannelData = data;
        this.locationData = data.locations;
        this.stateOfCorporationData = data.states;
      }
    });
  }

  ngOnDestroy() {
    this.getLocationVal();
  }

}
