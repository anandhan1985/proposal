import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { ProposalMemberComponent } from './proposal-member.component';

describe('ProposalMemberComponent', () => {
  let component: ProposalMemberComponent;
  let fixture: ComponentFixture<ProposalMemberComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ProposalMemberComponent],
      imports: [FormsModule, ReactiveFormsModule, HttpClientTestingModule],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposalMemberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
