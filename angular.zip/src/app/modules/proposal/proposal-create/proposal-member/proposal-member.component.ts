import { Component, OnInit } from '@angular/core';
import { CreateProposalService } from './../../shared/proposal-create.service';

@Component({
  selector: 'app-proposal-member',
  templateUrl: './proposal-member.component.html',
  styleUrls: ['./proposal-member.component.scss']
})
export class ProposalMemberComponent implements OnInit {
  private memberProposalData: any = [];

  constructor(private CreateProposalService: CreateProposalService) { }

  ngOnInit() {
    this.getProposalMemberInfoData();
  }

  getProposalMemberInfoData() {
    this.CreateProposalService.getProposalData().subscribe((data) => {
      if (data["memberInfo"])
        this.memberProposalData = data.memberInfo[0];
    });
  }

}
