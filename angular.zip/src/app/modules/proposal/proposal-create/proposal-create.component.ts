import { Component, OnInit } from '@angular/core';
import { CreateProposalService } from './../shared/proposal-create.service';
import { MessageDialogComponent } from '../../../shared/message-dialog/message-dialog.component'
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-proposal-create',
  templateUrl: './proposal-create.component.html',
  styleUrls: ['./proposal-create.component.scss']
})
export class ProposalCreateComponent implements OnInit {
  public createProposalData: any = [];
  private proposalMemberName = "";
  public proposalFormData: any;
  public resortDataDetails: any;
  private locationSelected = false;
  private navLinks: any = [
    { "path": "saleschannel", "label": "Location" },
    { "path": "membersummary", "label": "Member Summary" },
    { "path": "titleinsurance", "label": "Title" },
    { "path": "promotioncodes", "label": "Codes" },
    { "path": "additionalinfo", "label": "Additional Information" },
  ];
  constructor(private CreateProposalService: CreateProposalService, public dialog: MatDialog) { }

  ngOnInit() {
    this.getCreateProposalData();
    this.CreateProposalService.proposalDataCreate();
    this.proposalFormData = this.CreateProposalService.proposalDataCreate();
    this.resortDataDetails = this.CreateProposalService.resortDataPointsName();
    this.CreateProposalService.getSalesLocationReceived.subscribe(data => {
      this.locationSelected = (data != "") ? true : false;
    });
  }

  getCreateProposalData() {
    this.CreateProposalService.getCreateProposalData().subscribe((data) => {
      this.createProposalData = data;
      this.CreateProposalService.createPropValue.resort = this.proposalFormData.resort;
      this.proposalMemberName = (data && data.memberInfo && data.memberInfo.length) ? data.memberInfo[0].name : "";
    });
  }

  onSubmit() {
    let currPath: any = (window.location.href).split("/");
    currPath = currPath[currPath.length - 1];
    if (currPath == "saleschannel") {
      this.CreateProposalService.setLocationVal();
    } else if (currPath == "titleinsurance") {
      this.CreateProposalService.setTitleInsuranceVal();
    } else if (currPath == "additionalinfo") {
      this.CreateProposalService.setAddInfoVal();
    }
    this.CreateProposalService.postProposalData().subscribe((data) => {
      const dialogRef = this.dialog.open(MessageDialogComponent, {
        width: '200px',
        height: '150px',
        data: data.message
      });
    });
  }
}
