import { Component, OnInit } from '@angular/core';
import { CreateProposalService } from './../../shared/proposal-create.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-proposal-additional-info',
  templateUrl: './proposal-additional-info.component.html',
  styleUrls: ['./proposal-additional-info.component.scss']
})
export class ProposalAdditionalInfoComponent implements OnInit {
  private additionalInfoData: any = [];
  private guideData: any = [];
  private coGuideData: any = [];
  private qualityAssuranceManagerData: any = [];
  additionalInfoFG: FormGroup;
  constructor(private CreateProposalService: CreateProposalService, private fb: FormBuilder) {
    this.additionalInfoFG = this.fb.group({
      guide: [],
      coGide: [],
      qam: ["Qaa Generic Qaa (700)"],
      splInstruction: []
    })
  }

  ngOnInit() {
    this.getProposalAdditionalInfoData();
    this.setProposalAdditionalInfoData();
    this.CreateProposalService.getAddInfoReceived.subscribe(data => {
      this.getAddInfoVal();
    });
    this.additionalInfoFG.valueChanges.subscribe(data => {
      this.getAddInfoVal();
    });
  }

  setProposalAdditionalInfoData() {
    this.additionalInfoFG.patchValue({
      guide: this.CreateProposalService.createPropValue.guideID,
      coGide: this.CreateProposalService.createPropValue.coGuideID,
      qam: this.CreateProposalService.createPropValue.qamID,
      splInstruction: this.CreateProposalService.createPropValue.specialInstructions
    });
  }

  getProposalAdditionalInfoData() {
    this.CreateProposalService.getProposalData().subscribe((data) => {
      if (data["guides"]) {
        this.additionalInfoData = data["guides"];
        this.additionalInfoData.forEach(addlData => {
          if (addlData.type == "GUIDE")
            this.guideData.push(addlData);
          else if (addlData.type == "CO-GUIDE")
            this.coGuideData.push(addlData);
          else if (addlData.type == "QAM")
            this.qualityAssuranceManagerData.push(addlData);
        });
      }
    });
  }

  getAddInfoVal() {
    let additionalInfo: any = this.additionalInfoFG.value;
    this.CreateProposalService.createPropValue.guideID = additionalInfo.guide;
    this.CreateProposalService.createPropValue.coGuideID = additionalInfo.coGide;
    this.CreateProposalService.createPropValue.qamID = additionalInfo.qam;
    this.CreateProposalService.createPropValue.specialInstructions = additionalInfo.splInstruction;
  }

  ngOnDestroy() {
    // this.getAddInfoVal();
  }
}
