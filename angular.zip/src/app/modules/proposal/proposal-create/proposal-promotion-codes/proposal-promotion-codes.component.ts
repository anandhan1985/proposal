import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ProposalPromotionDialogComponent } from '../../../../shared/proposal-promotion-dialog/proposal-promotion-dialog.component'
import { CreateProposalService } from './../../shared/proposal-create.service';

@Component({
  selector: 'app-proposal-promotion-codes',
  templateUrl: './proposal-promotion-codes.component.html',
  styleUrls: ['./proposal-promotion-codes.component.scss']
})
export class ProposalPromotionCodesComponent implements OnInit {
  codesFG: FormGroup;
  codeDS: any[];
  ccpDS: any[];
  private selectedPromotionsData: any = [];
  private availablePromotions: any = [];
  private enableApplyPromotions = false;
  constructor(private fb: FormBuilder, public dialog: MatDialog, private CreateProposalService: CreateProposalService) { }

  ngOnInit() {
    this.codesFG = this.fb.group({
      code: [],
      ccp: []
    })
    this.enableApplyPromotions = (this.CreateProposalService.createPropValue.salesLocation == "") ? false : true;
    this.codeDS = [{ "id": 1, "code": "Cast Member Discount" }]
    this.ccpDS = [{ "id": 1, "code": "Seller Pays Additional $50" }]
  }

  openApplyPromotions(): void {
    this.CreateProposalService.getAvailablePromotionsData().subscribe((data) => {
      this.availablePromotions = data.promdetails;
      const dialogRef = this.dialog.open(ProposalPromotionDialogComponent, {
        width: '600px',
        height: '400px',
        data: this.availablePromotions
      });

      dialogRef.afterClosed().subscribe(result => {
        this.selectedPromotionsData = this.availablePromotions.filter(promo => {
          return result.indexOf(promo.promotioncode) > -1
        });
        this.CreateProposalService.createPropValue.promotion = this.selectedPromotionsData;
      });
    });
  }
}
