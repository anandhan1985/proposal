/* $(document).ready(function() {
	
    $("#searchBtn").click(function() {
        $("#createProposalDialog").dialog({
			modal: true,
			draggable: false,
			resizable: false,
			width: 400,	
			buttons: {
				"Create Proposal": function() {
					//$(this).dialog("close");
					window.location.href = "masterProposal.html"
					}
				}	
	});
	
    });

	$('#tabs').tabs();
	
}); */