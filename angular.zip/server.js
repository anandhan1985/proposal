var restify = require('restify');
const axios = require('axios');
const corsMiddleware = require('restify-cors-middleware')
const log4js = require('log4js');
log4js.configure({
    appenders: { hvc: { type: 'file', filename: 'restify-logs.log' } },
    categories: { default: { appenders: ['hvc'], level: 'trace' } }
});

const logger = log4js.getLogger('hvc');

var port = process.env.PORT || 3000;
const server = restify.createServer({
    name: 'myapp',
    version: '1.0.0'
});
//var url = "http://10.105.113.53:9007";
var url = "http://localhost:3001";
server.use(restify.plugins.acceptParser(server.acceptable));
server.use(restify.plugins.queryParser());
server.use(restify.plugins.jsonBodyParser({ mapParams: true }));
server.use(restify.plugins.fullResponse());

var retryMaxCount = 8;

const cors = corsMiddleware({
    origins: ['*'],
    allowHeaders: ['*'],
    allowMethods: ['GET,POST,PUT,PATCH,DELETE,OPTIONS']
})
server.pre(cors.preflight)
server.use(cors.actual)

// Aggregator service for fetching Create Proposal LOV data
server.get('/hvc/aggregatorSearch', aggregatorSearch);
server.get('/hvc/aggregatorProposal', aggregatorProposal);
server.get('/hvc/promotions', promotions);
server.post('/hvc/submitProposal', submitProposal);

function aggregatorSearch(req, res, next) {
    var aggregator = {};
    aggregator.error = [];
    let requestURLData = [
        { url: url + '/v1/resorts?attempt=0', type: 'resorts', value: 'resorts' }
    ];
    doMSCall(aggregator, requestURLData, res, 0);

}

function aggregatorProposal(req, res, next) {
    var aggregator = {};
   aggregator.requestId = generateRequestId();
    aggregator.error = [];
    let requestURLData = [
        { url: url + '/v1/members?attempt=0', type: 'memberInfo', value: 'guides' },
        { url: url + '/v1/titles?attempt=0', type: 'titles', value: 'titles' },
        { url: url + '/v1/states?attempt=0', type: 'states', value: 'states' },
        { url: url + '/v1/saleschannels?attempt=0', type: 'locations', value: 'locations' },
        { url: url + '/v1/roles?attempt=0', type: 'guides', value: 'guides' }
    ];

    logInfo("Aggregator Proposal Service called . Request Id --->> " + aggregator.requestId);
    doMSCall(aggregator, requestURLData, res, 0);
}

function promotions(req, res, next) {

    var aggregator = {};
    aggregator.error = [];
    let requestURLData = [
        { url: url + '/v1/promotions?location=' + req.query.location + "&membertype=" + req.query.membertype + "&resort=" + req.query.resort, type: 'promdetails', value: 'promdetails' }
    ];
    doMSCall(aggregator, requestURLData, res, 0);

}

function submitProposal(req, res, next) {
    axios.post(url + '/v1/submitProposal', req.body)
        .then(function (response) {
            console.log(response.data);
            res.send(response.data);
        })
        .catch(function (error) {
            console.log(error);
        });
}

function doMSCall(aggregator, requestURLData, res, retryCount) {
    if (retryCount < retryMaxCount) {
        logInfo("Retry Count --->>>> " + retryCount)
        aggregator.fails = [];
        aggregator.retryURLs = [];
        axios.all(
            getRequestData(aggregator, requestURLData)
        ).then(axios.spread(() => {
            if (aggregator.fails.length == 0) {

                logInfo("All responses succeeded. Sending response data to client");

                sendData(res, aggregator);
            } else {
                aggregator = getRetryURLS(aggregator);

                logTrace(aggregator.retryURLs.length + " endpoints totally failed. Will retry the following failure endpoints...");
                logInfoFromKey(aggregator.retryURLs, "url");

                if (aggregator.retryURLs.length > 0) {
                    let retryURLRequests = [];
                    aggregator.retryURLs.forEach(element => {
                        if (element.url.includes("?attempt=")) {
                            element.url = element.url.replace(/.$/, retryCount)
                        }
                        retryURLRequests.push({ url: element.url, type: element.type, value: element.value })
                    });

                    logInfo("Retry intiated for below " + retryURLRequests.length + " endpoints");
                    logInfoFromKey(retryURLRequests, 'url');

                    doMSCall(aggregator, retryURLRequests, res, retryCount + 1);
                } else {
                    logError("Endpoints not retriable.. Sending response with error notes to the client...")

                    sendData(res, aggregator);
                }
            }
        }))
    } else {
        logError("MAX Retry of count " + retryMaxCount + " reached.. Sending response with error notes to the client...")
        aggregator.errorNoRetry = "MAX RETRY limit reached for the service ";
        sendData(res, aggregator);
    }
}

function getRequestData(aggregator, requestURLData) {
    let data = [];
    requestURLData.forEach(element => {
        data.push(getAxiosRequest(aggregator, appendReqId(element.url, aggregator.requestId), element.type, element.value));
    });
    return data;
}
function getAxiosRequest(aggregator, url, type, value) {
    return axios.get(url).then((res) => {
        aggregator[type] = res.data[value];
        logTrace("Response received for " + url + " -> ");
        logTrace(aggregator[type]);
    }).catch(error => {
        aggregator.fails.push(getFailData(error, type, value));
        logTrace("Error received for " + url + " -> ");
        logError("Status -->>" + error.response.status + " -->> " + error.response.config.url);
    })
}

function getRetryURLS(aggregator) {
    aggregator.fails.forEach(elem => {
        if (isRetry(elem)) {
            logInfo("Error in endpoint : " + elem.url + " with error code " + elem.code + " to be retried");
            aggregator.retryURLs.push({ url: elem.url, type: elem.type, value: elem.value })
        } else {
            logTrace("Error in endpoint : " + elem.url + " with error code " + elem.code + " NEED NOT be retried and error response to be sent to client..");
            aggregator.error.push(getErrorData(elem));
        }
    });
    return aggregator;
}

function isRetry(error) {
    if (error.code >= 500 && error.code <= 599) {
        return true;
    } else {
        return false;
    }
}

function getFailData(error, type, value) {
    return { code: error.response.status, message: error.message, url: error.config.url, type: type, value: value };
}

function getErrorData(error) {
    debugger;
    return { code: error.code, message: error.message, url: error.url };
}

function sendData(res, aggregator) {
    delete aggregator['fails'];
    delete aggregator['retryURLs'];
    delete aggregator['requestId'];
    if (aggregator.error.length == 0)
        delete aggregator['error'];
    res.send(aggregator);

}

function generateRequestId() {
    return new Date().getTime() + "" + getRandomInt(1, 100);
}

function appendReqId(url, reqId) {
    if (url.indexOf('reqId') == -1) {
        let urlSplit = url.split("?");
        url = urlSplit[0] + "?reqId=" + reqId + "?" + urlSplit[1];
    }
    return url;
}

function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function logInfo(message) {
    logger.info(message);
}
function logInfoFromKey(array, key) {
    array.forEach(element => {
        logger.info(element[key]);
    });

}

function logError(message) {
    logger.error(message);
}
function logTrace(message) {
    logger.trace(message);
}

server.listen(port, function () {
    console.log('%s listening at %s', server.name, server.url);
});
