var restify = require('restify');
var port = process.env.PORT || 3001;
const server = restify.createServer({
    name: 'myapp',
    version: '1.0.0'
});

server.use(restify.plugins.acceptParser(server.acceptable));
server.use(restify.plugins.queryParser());
server.use(restify.plugins.bodyParser());

server.get('/v1/resorts', resorts);
server.get('/v1/states', states);
server.get('/v1/titles', titles);
server.get('/v1/members', members);
server.get('/v1/saleschannels', locations);
server.get('/v1/roles', guides);
server.get('/v1/promotions', promotions);
server.post('/v1/proposal', proposal);


function resorts(req, res, next) {
    var resorts = {
        "resorts": [{ "resort": 1, "resortName": "POLYV - Disney's Polynesian Villas and Bungalow", "resortPointPrice": 50 },
        { "resort": 2, "resortName": "Green peak resort", "resortPointPrice": 20 }]
    }

    setTimeout(function () {
        res.send(200, resorts);
    }, 500);

}

function members(req, res, next) {
    var member = {
        "guides": [
            { "id": 100, "name": "Dpbmob Resalesman", "address": "200 Celebration Blvd, Kissimmee, FL 34747-5011", "memberType": "test", "principal": "n", "trustee": "" }
        ]
    }
    setTimeout(function () {
        res.send(200, member);
    }, 1000);

}

function states(req, res, next) {
    var states = {
        "states": [
            { "id": 1, "name": "Florida" },
            { "id": 2, "name": "Orlando" },
        ]
    }
    setTimeout(function () {
        // res.send(200, states);
        if (req.query.attempt == 5) {
            res.send(200, states);
        } else {
            res.send(501, "Internal Server Error");
        }
    }, 1300);

}

function titles(req, res, next) {
    var titles = {
        "titles": [
            { "titleCode": 1, "titleDescription": "As Community Property" },
            { "titleCode": 2, "titleDescription": "As Community Property with Right or Surviorship" },
            { "titleCode": 3, "titleDescription": "As Joint Tenants with Right or Surviorship" },
            { "titleCode": 4, "titleDescription": "As Tenants in Common" },
            { "titleCode": 5, "titleDescription": "As Joint Tenants with Right or Surviorship And Not as Tenants in Common" },
            { "titleCode": 6, "titleDescription": "As Tenants By the Entirety" }
        ]
    }
    res.send(200, titles);
}

function locations(req, res, next) {
    var locations = {
        "locations": [
            { "location": 1, "description": "Animal Kingdom Lodge" },
            { "location": 2, "description": "Celebration" }
        ]
    }
    res.send(200, locations);
}

function guides(req, res, next) {
    var guides = {
        "guides": [
            { "id": 1, "name": "ADAM LOSSER (2136)", "type": "Guide" },
            { "id": 2, "name": "AJ Spencer (2343)", "type": "Guide" },
            { "id": 3, "name": "Aaron Powell (2135)", "type": "Co-Guide" },
            { "id": 4, "name": "Adharsh Singh (2137)", "type": "Co-Guide" },
            { "id": 5, "name": "Qaa Generic Qaa (700)", "type": "QAM" },
            { "id": 6, "name": "Akira Iwata (7349)", "type": "QAM" },
            { "id": 7, "name": "Alko Teruta (3546)", "type": "QAM" },
        ]

    }
    res.send(200, guides);
}

function promotions(req, res, next) {
    var promotions = {
        "promdetails": [
            {
                "promotioncode": "DF20150926",
                "description": "Initial",
                "category": "Test"
            },
            {
                "promotioncode": "DF20150927",
                "description": "Variety",
                "category": "Test"
            }
        ]
    }
    res.send(200, promotions);
}

function proposal(req, res, next) {
    console.log("Inside Post MS");
    console.log(req.body);
    var data = {
        "id": "AA0763",
        "code": "S001",
        "message": "Data Saved Successfully"
    }
    setTimeout(function () {
        res.send(200, data);
    }, 500);

}

server.listen(port, function () {
    console.log('%s listening at %s', server.name, server.url);
});